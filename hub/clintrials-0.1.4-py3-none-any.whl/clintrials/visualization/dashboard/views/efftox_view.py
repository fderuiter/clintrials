"""Renders the EffTox simulation results view in the Streamlit dashboard.

Random Seed Strategy: {efftox_view_seed_strategy}
"""

import streamlit as st

from clintrials.dosefinding.efftox import EffTox
from clintrials.visualization.dashboard.views.framework import BaseSimulationView


class EffToxView(BaseSimulationView):  # type: ignore
    """View class for the Efficacy-Toxicity (EffTox) model."""

    model_name = "EffTox"
    title = "EffTox Simulation Results"
    file_prefix = "efftox_simulations"
    model_class = EffTox  # type: ignore
    param_space_config = {
        "true_prob_tox": [(0.05, 0.1, 0.2, 0.3, 0.4)],
        "true_prob_eff": [(0.2, 0.3, 0.4, 0.5, 0.6)],
    }
    var_map = {  # type: ignore
        "true_prob_tox": "true_prob_tox",
        "true_prob_eff": "true_prob_eff",
    }

    @classmethod
    def preview_sims(cls, target_tox, cohort_size, max_size):  # type: ignore
        """Generate preview simulations for the EffTox model."""
        from clintrials.core.simulation import run_bivariate_simulations
        from clintrials.dosefinding.efftox import EffTox, LpNormCurve

        real_doses = [1.0, 2.0, 3.0, 4.0, 5.0]
        prior_tox_probs = [0.05, 0.1, 0.2, 0.3, 0.4]
        prior_eff_probs = [0.2, 0.4, 0.6, 0.7, 0.8]

        metric = LpNormCurve(0.2, 0.4, 0.5, 0.2)
        trial = EffTox(
            real_doses=real_doses,
            prior_tox_probs=prior_tox_probs,
            prior_eff_probs=prior_eff_probs,
            tox_cutoff=0.4,
            eff_cutoff=0.2,
            tox_certainty=0.8,
            eff_certainty=0.8,
            metric=metric,
            max_size=max_size,
        )

        tox_scenarios = [(0.05, 0.1, 0.2, 0.3, 0.4)]
        eff_scenarios = [(0.2, 0.3, 0.4, 0.5, 0.6)]

        return run_bivariate_simulations(trial, tox_scenarios, eff_scenarios, cohort_size, n_replicates=10)

    @classmethod
    def build_figures(cls, summary_df):  # type: ignore
        """Generate visualization plots for the EffTox summary dataframe."""
        figures = []
        if not summary_df.empty:
            if "recommended_dose_prob" in summary_df.columns:
                from clintrials.core.viz_interface import get_visualization_provider
                fig_rec = get_visualization_provider().plot_bivariate_simulation_recommendation(  # type: ignore
                    summary_df,
                    high_contrast=False
                )
                figures.append(("Dose Recommendation Probability", fig_rec))

            if (
                "prob_accept_tox" in summary_df.columns
                and "prob_accept_eff" in summary_df.columns
            ):
                from clintrials.core.viz_interface import get_visualization_provider
                fig_accept = get_visualization_provider().plot_efftox_simulation_acceptability(  # type: ignore
                    summary_df,
                    high_contrast=False
                )
                figures.append(("Acceptability Probabilities", fig_accept))
        else:
            st.warning("Summary dataframe is empty. Cannot generate plots.")

        return figures
