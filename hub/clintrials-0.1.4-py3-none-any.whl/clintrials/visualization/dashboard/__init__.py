"""Dashboard visualization components."""
