"""Base classes and utilities for efficacy-toxicity dose-finding trials.

Random Seed Strategy: {efficacytoxicity_seed_strategy}
"""

from __future__ import annotations

from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

__author__ = "brockk"


import abc
import logging
from collections import OrderedDict
from itertools import combinations_with_replacement

from clintrials.utils import (
    atomic_to_json,
    correlated_binary_outcomes_from_uniforms,
    iterable_to_json,
)

logger = logging.getLogger(__name__)


from clintrials.core.protocol import BaseDoseFindingTrial


class EfficacyToxicityDoseFindingTrial(BaseDoseFindingTrial):
    """An abstract base class for dose-finding trials.

    Jointly monitors toxicity and efficacy.

    Warning:
        Data updates are strictly incremental. Do not repeatedly pass the full
        patient history to the `update` method, as this will append duplicates
        to the internal records rather than replacing them. If you need to
        reload the full history (e.g., for data corrections), use the `reset()`
        method first.
    """

    def __init__(self, first_dose: int, num_doses: int, max_size: int) -> None:
        """Initializes an EfficacyToxicityDoseFindingTrial object.

        Args:
            first_dose (int): The starting dose level (1-based).
            num_doses (int): The total number of dose levels.
            max_size (int): The maximum number of patients in the trial.

        Raises:
            ValueError: If `first_dose` is greater than `num_doses`.
        """
        super().__init__(first_dose=first_dose, num_doses=num_doses, max_size=max_size)
        self._admissable_set = []  # type: ignore

    @property
    def _efficacies(self) -> List[int]:
        return self._tracker.efficacies

    def dose_levels(self) -> Iterable[int]:
        """Gets a list of the dose levels (1-based indices).

        Returns:
            list[int]: A list of dose levels.
        """
        return list(range(1, self.num_doses + 1))

    def efficacies(self) -> List[int]:
        """Gets the list of observed efficacies.

        Returns:
            list[int]: A list of efficacy outcomes (1 for efficacy, 0 for no
                efficacy).
        """
        return self._efficacies

    def efficacies_at_dose(self, dose: int) -> int:
        """Gets the number of efficacies observed at a specific dose level.

        Args:
            dose (int): The 1-based dose level.

        Returns:
            int: The number of efficacies at the given dose.
        """
        return sum([e for d, e in zip(self.doses(), self.efficacies()) if d == dose])

    def tabulate(self) -> pd.DataFrame:
        """Generates a summary table of the trial data.

        Returns:
            pandas.DataFrame: A DataFrame with the summary of patients,
                efficacies, and toxicities for each dose level.
        """
        import pandas as pd

        tab_data = OrderedDict()
        treated_at_dose = [self.treated_at_dose(d) for d in self.dose_levels()]
        eff_at_dose = [self.efficacies_at_dose(d) for d in self.dose_levels()]
        tox_at_dose = [self.toxicities_at_dose(d) for d in self.dose_levels()]
        tab_data["Dose"] = self.dose_levels()
        tab_data["N"] = treated_at_dose
        tab_data["Efficacies"] = eff_at_dose
        tab_data["Toxicities"] = tox_at_dose
        df = pd.DataFrame(tab_data)
        df["EffRate"] = np.where(df.N > 0, df.Efficacies / df.N, np.nan)
        df["ToxRate"] = np.where(df.N > 0, df.Toxicities / df.N, np.nan)
        return df

    def update(self, cases: List[Tuple[int, int, int]], **kwargs: Any) -> int:  # type: ignore[override]
        """Updates the trial with a list of new cases.

        Warning:
            This method is strictly incremental. It appends the provided cases
            to the internal record rather than replacing existing records.
            Calling `update()` with the full patient history repeatedly will
            duplicate existing records.

        Args:
            cases (list[tuple[int, int, int]]): A list of new cases to append, where each
                case is a tuple of (dose, toxicity, efficacy).
            **kwargs: Additional keyword arguments for the dose calculation.

        Returns:
            int: The next recommended dose level.
        """
        if len(cases) > 0:
            doses = []
            toxicities = []
            efficacies = []
            for case in cases:
                if len(case) < 3:
                    from clintrials.core.errors import ErrorTemplates
                    raise ValueError(ErrorTemplates.EXPECTED_LENGTH.format(name="Patient outcome", expected_length=3))
                doses.append(case[0])
                toxicities.append(case[1])
                efficacies.append(case[2])

            self._tracker.add_patients(doses=doses, toxicities=toxicities, efficacies=efficacies)
            self._next_dose = self._calculate_next_dose(**kwargs)
        else:
            logging.warning("Cannot update design with no cases")

        return self._next_dose

    def admissable_set(self) -> Any:
        """Gets the current set of admissible doses.

        Returns:
            list[int]: The list of admissible dose levels.
        """
        return self._admissable_set

    def dose_admissability(self) -> Any:
        """Gets a boolean array indicating the admissibility of each dose.

        Returns:
            numpy.ndarray: A boolean array where `True` indicates that the
                dose is admissible.
        """
        return np.array([(x in self._admissable_set) for x in self.dose_levels()])

    def observed_efficacy_rates(self) -> Any:
        """Gets the observed efficacy rate for each dose level.

        Returns:
            numpy.ndarray: An array of observed efficacy rates.
        """
        eff_rates = []
        for d in range(1, self.num_doses + 1):
            num_treated = self.treated_at_dose(d)
            if num_treated:
                num_responses = self.efficacies_at_dose(d)
                eff_rates.append(1.0 * num_responses / num_treated)
            else:
                eff_rates.append(np.nan)
        return np.array(eff_rates)

    def optimal_decision(self, prob_tox: Sequence[float], prob_eff: Sequence[float]) -> int:
        """Gets the optimal dose choice for given toxicity and efficacy curves.

        Args:
            prob_tox (list[float]): A list of toxicity probabilities.
            prob_eff (list[float]): A list of efficacy probabilities.

        Returns:
            int: The optimal 1-based dose level.
        """
        raise NotImplementedError()

    def has_more(self) -> bool:
        """Checks if the trial is ongoing.

        Returns:
            bool: `True` if the trial is ongoing, `False` otherwise.
        """
        return (self.size() < self.max_size()) and (self._status >= 0)

    def report(self) -> Dict[str, Any]:
        """Generates a standardized JSON-serializable report of the trial.

        Returns:
            collections.OrderedDict: The trial outcome report.
        """
        from collections import OrderedDict

        from clintrials.utils import atomic_to_json, iterable_to_json

        report = OrderedDict()
        report["RecommendedDose"] = atomic_to_json(self.next_dose())  # type: ignore
        report["TrialStatus"] = atomic_to_json(self.status())  # type: ignore
        report["Doses"] = iterable_to_json(self.doses())  # type: ignore
        report["Toxicities"] = iterable_to_json(self.toxicities())  # type: ignore
        report["Efficacies"] = iterable_to_json(self.efficacies())  # type: ignore
        return report

    @abc.abstractmethod
    def _calculate_next_dose(self, **kwargs: Any) -> Any:
        """Calculates the next dose to be administered.

        Subclasses should override this method.

        Returns:
            int: The next recommended dose level.
        """
        return -1


def _efftox_patient_outcome_to_label(po: Any) -> Any:
    """Converts a patient outcome tuple to a string label.

    Args:
        po (tuple[int, int]): A tuple representing the patient outcome,
            where the first element is toxicity (1 or 0) and the second is
            efficacy (1 or 0).

    Returns:
        str: A string label for the outcome (e.g., "Neither", "Toxicity",
            "Efficacy", "Both").
    """
    if po == (0, 0):
        return "Neither"
    elif po == (1, 0):
        return "Toxicity"
    elif po == (0, 1):
        return "Efficacy"
    elif po == (1, 1):
        return "Both"
    else:
        return "Error"


def _efftox_outcome_generator(design: Any, current_size: Any, cohort_size: Any, true_toxicities: Any, true_efficacies: Any, tox_eff_odds_ratio: Any, tolerances: Any, correlated_outcomes: Any, **kwargs: Any) -> Any:
    dose_level = design.next_dose()
    u = (true_toxicities[dose_level - 1], true_efficacies[dose_level - 1])
    if correlated_outcomes:
        events = correlated_binary_outcomes_from_uniforms(
            tolerances[current_size : current_size + cohort_size,], u, psi=tox_eff_odds_ratio
        ).astype(int)
    else:
        events = (tolerances[current_size : current_size + cohort_size, 0:2] < u).astype(int)
    return np.column_stack(([dose_level] * cohort_size, events))

def _simulate_trial(design: Any, true_toxicities: Any, true_efficacies: Any, tox_eff_odds_ratio: Any = 1.0, tolerances: Any = None, cohort_size: Any = 1, conduct_trial: Any = 1, calculate_optimal_decision: Any = 1, recruitment_stream: Any = None) -> Any:
    """Simulates a single efficacy-toxicity dose-finding trial.

    Args:
        design (EfficacyToxicityDoseFindingTrial): The trial design to use.
        true_toxicities (list[float]): The true toxicity rates for each dose.
        true_efficacies (list[float]): The true efficacy rates for each dose.
        tox_eff_odds_ratio (float, optional): The odds ratio for the
            association between toxicity and efficacy. Defaults to 1.0.
        tolerances (numpy.ndarray, optional): An array of uniform random
            numbers for simulating patient outcomes. If `None`, random
            numbers are generated. Defaults to `None`.
        cohort_size (int, optional): The number of patients per cohort.
            Defaults to 1.
        conduct_trial (bool, optional): If `True`, conducts the trial
            cohort-by-cohort. Defaults to `True`.
        calculate_optimal_decision (bool, optional): If `True`, calculates
            the optimal dose decision. Defaults to `True`.
        recruitment_stream (iterator, optional): An optional iterator providing recruitment times.

    Returns:
        collections.OrderedDict: A dictionary containing the simulation report.

    Raises:
        ValueError: If the lengths of `true_efficacies`, `true_toxicities`,
            and the number of doses in the design do not match, or if
            `tolerances` has incorrect dimensions.
    """
    correlated_outcomes = tox_eff_odds_ratio < 1.0 or tox_eff_odds_ratio > 1.0

    # Simulate trial
    if conduct_trial:
        from clintrials.core.simulation import UniversalProtocolSimulationRunner
        runner = UniversalProtocolSimulationRunner(
            design=design,
            outcome_generator=_efftox_outcome_generator,  # type: ignore[arg-type]
            recruitment_stream=recruitment_stream
        )
        sim_report = runner.run(
            cohort_size=cohort_size,
            true_toxicities=true_toxicities,
            true_efficacies=true_efficacies,
            tox_eff_odds_ratio=tox_eff_odds_ratio,
            tolerances=tolerances,
            correlated_outcomes=correlated_outcomes
        )

    # Report findings
    report = OrderedDict()
    # report['TrueToxicities'] = iterable_to_json(true_toxicities)
    # report['TrueEfficacies'] = iterable_to_json(true_efficacies)
    # Do not parrot back parameters

    if conduct_trial:
        if isinstance(sim_report, list):
            sim_report = sim_report[0]
        report.update(sim_report)
    # Optimal decision, given these specific patient tolerances
    if calculate_optimal_decision:
        try:
            if correlated_outcomes:
                tox_eff_hat = np.array(
                    [
                        correlated_binary_outcomes_from_uniforms(
                            tolerances, v, psi=tox_eff_odds_ratio
                        ).mean(axis=0)
                        for v in zip(true_toxicities, true_efficacies)
                    ]
                )
                tox_hat, eff_hat = tox_eff_hat[:, 0], tox_eff_hat[:, 1]
            else:
                had_tox = lambda x: x < np.array(true_toxicities)
                tox_horizons = np.array([had_tox(x) for x in tolerances[:, 0]])  # type: ignore
                tox_hat = tox_horizons.mean(axis=0)
                had_eff = lambda x: x < np.array(true_efficacies)
                eff_horizons = np.array([had_eff(x) for x in tolerances[:, 1]])  # type: ignore
                eff_hat = eff_horizons.mean(axis=0)

            optimal_allocation = design.optimal_decision(tox_hat, eff_hat)
            report["FullyInformedToxicityCurve"] = iterable_to_json(  # type: ignore
                np.round(tox_hat, 4)
            )
            report["FullyInformedEfficacyCurve"] = iterable_to_json(  # type: ignore
                np.round(eff_hat, 4)
            )
            report["OptimalAllocation"] = atomic_to_json(optimal_allocation)  # type: ignore
        except NotImplementedError:
            pass

    return report


def simulate_trial(design: Any, true_toxicities: Any, true_efficacies: Any, tox_eff_odds_ratio: Any = 1.0, tolerances: Any = None, cohort_size: Any = 1, conduct_trial: Any = 1, calculate_optimal_decision: Any = 1, recruitment_stream: Any = None) -> Any:
    """Simulates a single efficacy-toxicity dose-finding trial.

    This function is a wrapper around `_simulate_trial` that performs input
    validation and generates random tolerances if not provided.

    Args:
        design (EfficacyToxicityDoseFindingTrial): The trial design to use.
        true_toxicities (list[float]): The true toxicity rates for each dose.
        true_efficacies (list[float]): The true efficacy rates for each dose.
        tox_eff_odds_ratio (float, optional): The odds ratio for the
            association between toxicity and efficacy. Defaults to 1.0.
        tolerances (numpy.ndarray, optional): An array of uniform random
            numbers for simulating patient outcomes. If `None`, random
            numbers are generated. Defaults to `None`.
        cohort_size (int, optional): The number of patients per cohort.
            Defaults to 1.
        conduct_trial (bool, optional): If `True`, conducts the trial
            cohort-by-cohort. Defaults to `True`.
        calculate_optimal_decision (bool, optional): If `True`, calculates
            the optimal dose decision. Defaults to `True`.
        recruitment_stream (iterator, optional): An optional iterator providing recruitment times.

    Returns:
        collections.OrderedDict: A dictionary containing the simulation report.
    """
    # Validation and derivation of the inputs
    if len(true_efficacies) != len(true_toxicities):
        raise ValueError("true_efficacies and true_toxicities should be same length.")
    if len(true_toxicities) != design.number_of_doses():
        raise ValueError(
            "Length of true_toxicities and number of doses should be the same."
        )
    n_patients = design.max_size()
    if tolerances is not None:
        if tolerances.ndim != 2 or tolerances.shape[0] < n_patients:
            raise ValueError("tolerances should be an n_patients*3 array")
    else:
        tolerances = np.random.uniform(size=3 * n_patients).reshape(n_patients, 3)

    if tox_eff_odds_ratio != 1.0 and calculate_optimal_decision:
        logging.warning(
            "Patient outcomes are not sequential when toxicity and efficacy events are correlated. "
            + "E.g. toxicity at d_1 dose not necessarily imply toxicity at d_2. It is important "
            + "to appreciate this when calculating optimal decisions."
        )

    return _simulate_trial(
        design,
        true_toxicities,
        true_efficacies,
        tox_eff_odds_ratio,
        tolerances,
        cohort_size,
        conduct_trial,
        calculate_optimal_decision,
        recruitment_stream,
    )


def simulate_efficacy_toxicity_dose_finding_trials(design_map: Any, true_toxicities: Any, true_efficacies: Any, tox_eff_odds_ratio: Any = 1.0, tolerances: Any = None, cohort_size: Any = 1, conduct_trial: Any = 1, calculate_optimal_decision: Any = 1, recruitment_stream: Any = None) -> Any:
    """Simulates multiple efficacy-toxicity dose-finding trials.

    This method allows for the comparison of different designs on the same set
    of simulated patient outcomes.

    Args:
        design_map (dict[str, EfficacyToxicityDoseFindingTrial]): A dictionary
            mapping design labels to trial design objects.
        true_toxicities (list[float]): The true toxicity rates for each dose.
        true_efficacies (list[float]): The true efficacy rates for each dose.
        tox_eff_odds_ratio (float, optional): The odds ratio for the
            association between toxicity and efficacy. Defaults to 1.0.
        tolerances (numpy.ndarray, optional): An array of uniform random
            numbers for simulating patient outcomes. If `None`, random
            numbers are generated. Defaults to `None`.
        cohort_size (int, optional): The number of patients per cohort.
            Defaults to 1.
        conduct_trial (bool, optional): If `True`, conducts the trial
            cohort-by-cohort. Defaults to `True`.
        calculate_optimal_decision (bool, optional): If `True`, calculates
            the optimal dose decision. Defaults to `True`.
        recruitment_stream (iterator, optional): An optional iterator providing recruitment times.

    Returns:
        collections.OrderedDict: A dictionary of simulation reports, with
            keys corresponding to the design labels.
    """
    max_size = max([design.max_size() for design in design_map.values()])
    if tolerances is not None:
        if tolerances.ndim != 2 or tolerances.shape[0] < max_size:
            raise ValueError("tolerances should be an max_size*3 array")
    else:
        tolerances = np.random.uniform(size=3 * max_size).reshape(max_size, 3)

    if tox_eff_odds_ratio != 1.0 and calculate_optimal_decision:
        logging.warning(
            "Patient outcomes are not sequential when toxicity and efficacy events are correlated. "
            + "E.g. toxicity at d_1 dose not necessarily imply toxicity at d_2. It is important "
            + "to appreciate this when calculating optimal decisions."
        )

    report = OrderedDict()
    # report['TrueToxicities'] = iterable_to_json(true_toxicities)
    # report['TrueEfficacies'] = iterable_to_json(true_efficacies)
    # Do not parrot back parameters

    for label, design in design_map.items():
        this_sim = _simulate_trial(
            design,
            true_toxicities,
            true_efficacies,
            tox_eff_odds_ratio,
            tolerances,
            cohort_size,
            conduct_trial,
            calculate_optimal_decision,
            recruitment_stream,
        )
        report[label] = this_sim

    return report


def dose_transition_pathways(trial: Any, next_dose: Any, cohort_sizes: Any, cohort_number: Any = 1, cases_already_observed: Any = [], custom_output_func: Any = None, verbose: Any = False, **kwargs: Any) -> Any:
    """Calculates the dose-transition pathways for an efficacy-toxicity design.

    Args:
        trial (EfficacyToxicityDoseFindingTrial): The trial design object.
        next_dose (int): The dose to be given to the next cohort.
        cohort_sizes (list[int]): A list of future cohort sizes.
        cohort_number (int, optional): The starting cohort number.
            Defaults to 1.
        cases_already_observed (list, optional): A list of cases that have
            already been observed. Defaults to an empty list.
        custom_output_func (Callable, optional): A function that takes the
            trial object and returns a dictionary of extra output. Defaults
            to `None`.
        verbose (bool, optional): If `True`, prints progress information.
            Defaults to `False`.
        **kwargs: Additional keyword arguments to pass to the `trial.update`
            method.

    Returns:
        dict: A nested dictionary representing the dose-transition pathways.
    """
    if len(cohort_sizes) <= 0:
        return None
    else:
        cohort_size = cohort_sizes[0]
        patient_outcomes = [(0, 0), (0, 1), (1, 0), (1, 1)]
        cohort_outcomes = list(
            combinations_with_replacement(patient_outcomes, cohort_size)
        )
        path_outputs = []
        for i, path in enumerate(cohort_outcomes):
            # Invoke dose-decision
            cohort_cases = [(next_dose, x[0], x[1]) for x in path]
            cases = cases_already_observed + cohort_cases
            if verbose:
                logger.debug("Running %s", cases)
            trial.reset()
            obd = trial.update(cases, **kwargs)
            # Collect output
            bag_o_tricks = OrderedDict(
                [
                    (f"Pat{cohort_number}.{j+1}", _efftox_patient_outcome_to_label(po))
                    for (j, po) in enumerate(path)
                ]
            )
            bag_o_tricks.update(
                OrderedDict(
                    [
                        ("DoseGiven", atomic_to_json(next_dose)),  # type: ignore
                        ("RecommendedDose", atomic_to_json(obd)),  # type: ignore
                        ("CohortSize", cohort_size),
                        ("NumEff", sum([x[1] for x in path])),
                        ("NumTox", sum([x[0] for x in path])),
                    ]
                )
            )
            if custom_output_func:
                bag_o_tricks.update(custom_output_func(trial))

            # Recurse subsequent cohorts
            further_paths = dose_transition_pathways(
                trial,
                next_dose=obd,
                cohort_sizes=cohort_sizes[1:],
                cohort_number=cohort_number + 1,
                cases_already_observed=cases,
                custom_output_func=custom_output_func,
                verbose=verbose,
                **kwargs,
            )
            if further_paths:
                bag_o_tricks["Next"] = further_paths

            path_outputs.append(bag_o_tricks)

        return path_outputs


def get_path(x: Any, dose_label_func: Optional[Callable] = None) -> Any:  # type: ignore
    """Constructs a string representation of a dose-transition path.

    Args:
        x (dict): A dictionary representing a single step in the DTP.
        dose_label_func (Callable, optional): A function to format the dose
            label. Defaults to `str`.

    Returns:
        str: A string representation of the path.
    """
    if dose_label_func is None:
        dose_label_func = lambda x: str(x)
    path = [x[z] for z in sorted([z for z in x.keys() if "Pat" in z])]
    path = [z[0] for z in path]
    path = "".join(path)  # type: ignore
    path = dose_label_func(x["DoseGiven"]) + path  # type: ignore
    return path


def _efftox_row_formatter(x: Any, dose_label_func: Any, verbose: Any = False) -> Any:
    path = get_path(x, dose_label_func=dose_label_func)
    obd = x["RecommendedDose"]
    prob_sup = x["MinProbSuperiority"]

    if verbose:
        util = [x["Utility1"], x["Utility2"], x["Utility3"], x["Utility4"]]
        prob_acc_eff = [
            x["ProbAccEff1"],
            x["ProbAccEff2"],
            x["ProbAccEff3"],
            x["ProbAccEff4"],
        ]
        prob_acc_tox = [
            x["ProbAccTox1"],
            x["ProbAccTox2"],
            x["ProbAccTox3"],
            x["ProbAccTox4"],
        ]
        template_txt = "{} -> Dose {}, Sup={}, Util={}, Pr(Acc Eff)={}, Pr(Acc Tox)={}"
        return template_txt.format(
            path,
            dose_label_func(obd),
            np.round(prob_sup, 2),
            np.round(util, 2),
            np.round(prob_acc_eff, 2),
            np.round(prob_acc_tox, 2),
        )
    else:
        if prob_sup < 0.6:
            template_txt = "{} -> Dose {}, Superiority={} * tentative *"
        else:
            template_txt = "{} -> Dose {}, Superiority={}"
        return template_txt.format(path, dose_label_func(obd), np.round(prob_sup, 2))


def print_dtps(dtps: Any, indent: int = 0, dose_label_func: Optional[Callable] = None) -> Any:  # type: ignore
    """Prints the dose-transition pathways.

    Args:
        dtps (dict): A nested dictionary of DTPs.
        indent (int, optional): The indentation level. Defaults to 0.
        dose_label_func (Callable, optional): A function to format the dose
            label. Defaults to `str`.
    """
    from clintrials.dosefinding import print_dtps as base_print_dtps

    base_print_dtps(
        dtps,
        indent=indent,
        dose_label_func=dose_label_func,
        row_formatter=_efftox_row_formatter,
        verbose=False,
    )


def print_dtps_verbose(dtps: Any, indent: int = 0, dose_label_func: Optional[Callable] = None) -> Any:  # type: ignore
    """Prints the dose-transition pathways with verbose information.

    Args:
        dtps (dict): A nested dictionary of DTPs.
        indent (int, optional): The indentation level. Defaults to 0.
        dose_label_func (Callable, optional): A function to format the dose
            label. Defaults to `str`.
    """
    from clintrials.dosefinding import print_dtps as base_print_dtps

    base_print_dtps(
        dtps,
        indent=indent,
        dose_label_func=dose_label_func,
        row_formatter=_efftox_row_formatter,
        verbose=True,
    )


# Inject module-level docstring
if __doc__:
    from clintrials.core.registry import CORE_REGISTRY
    __doc__ = __doc__.format(**CORE_REGISTRY)
