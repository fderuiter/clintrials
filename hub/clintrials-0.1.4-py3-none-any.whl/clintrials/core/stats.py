# SPDX-License-Identifier: MIT

"""Classes and methods to perform general useful statistical routines.

Random Seed Strategy: {stats_seed_strategy}
"""

from __future__ import annotations

__author__ = "Kristian Brock"
__contact__ = "kristian.brock@gmail.com"



from typing import Any, Callable

import numpy as np
from scipy.stats import norm


class ProbabilityDensitySample:
    """Represents a sample from a probability density function.

    This class provides methods to calculate properties of the distribution,
    such as expectation, variance, CDF, and quantiles.
    """

    def __init__(self, samp: Any, func: Callable[[Any], Any]) -> None:
        """Initializes a ProbabilityDensitySample object.

        Args:
            samp (numpy.ndarray): The sample from the distribution.
            func (Callable): A function that takes the sample and returns
                the probabilities.
        """
        from clintrials.core.errors import ErrorTemplates
        self._samp = samp
        self._probs = func(samp)
        self._scale = self._probs.mean()
        if self._scale <= 0:
            raise ValueError(ErrorTemplates.GT.format(name="scale", bound=0))

    def expectation(self, vector):  # type: ignore
        """Calculates the expectation of a vector.

        Args:
            vector (numpy.ndarray): The vector for which to calculate the
                expectation.

        Returns:
            float: The expectation of the vector.
        """
        return np.mean(vector * self._probs / self._scale)

    def variance(self, vector):  # type: ignore
        """Calculates the variance of a vector.

        Args:
            vector (numpy.ndarray): The vector for which to calculate the
                variance.

        Returns:
            float: The variance of the vector.
        """
        exp = self.expectation(vector)  # type: ignore
        exp2 = self.expectation(vector**2)  # type: ignore
        return exp2 - exp**2

    @property
    def samples(self) -> Any:
        """Exposes the samples array as a read-only property.

        Returns:
            numpy.ndarray: The sample from the distribution.
        """
        return self._samp

    def resample(self, boot_samps: int, rng: Any = None) -> np.ndarray[Any, Any]:
        """Performs bootstrap resampling internally and returns the resampled distributions.

        Args:
            boot_samps (int): The number of bootstrap samples to draw.
            rng (numpy.random.Generator, optional): Random number generator.

        Returns:
            numpy.ndarray: The resampled distribution array.
        """
        p = self._probs / self._probs.sum()
        if rng is not None:
            dist = rng.multinomial(boot_samps, p)
        else:
            dist = np.random.multinomial(boot_samps, p)

        samp_boot = []
        for j, count in enumerate(dist):
            if count > 0:
                samp_boot.extend([self._samp[j]] * count)
        return np.array(samp_boot)


def log_scale_wald_interval(ratio: float, standard_error: float, alpha: float = 0.05) -> tuple[float, float]:
    """Calculates the Wald confidence interval for a ratio on the log scale.

    Args:
        ratio (float): The estimated ratio.
        standard_error (float): The standard error of the log ratio.
        alpha (float): The significance level.

    Returns:
        tuple[float, float]: The lower and upper bounds of the confidence interval.
    """
    from clintrials.core.errors import ErrorTemplates
    if ratio <= 0:
        raise ValueError(ErrorTemplates.GT.format(name="ratio", bound=0))
    if standard_error <= 0:
        raise ValueError(ErrorTemplates.GT.format(name="standard_error", bound=0))

    z_score = norm.ppf(1 - alpha / 2)
    log_ratio = np.log(ratio)
    lower_bound_log = log_ratio - z_score * standard_error
    upper_bound_log = log_ratio + z_score * standard_error
    return (float(np.exp(lower_bound_log)), float(np.exp(upper_bound_log)))


def log_scale_p_value(ratio: float, standard_error: float) -> float:
    """Calculates the two-sided p-value for a ratio using a Wald test on the log scale.

    Args:
        ratio (float): The estimated ratio.
        standard_error (float): The standard error of the log ratio.

    Returns:
        float: The p-value.
    """
    from clintrials.core.errors import ErrorTemplates
    if ratio <= 0:
        raise ValueError(ErrorTemplates.GT.format(name="ratio", bound=0))
    if standard_error <= 0:
        raise ValueError(ErrorTemplates.GT.format(name="standard_error", bound=0))

    observed_z = np.log(ratio) / standard_error
    return float(2 * norm.sf(abs(observed_z)))


# Inject module-level docstring
if __doc__:
    from clintrials.core.registry import CORE_REGISTRY
    __doc__ = __doc__.format(**CORE_REGISTRY)
