# SPDX-License-Identifier: MIT

"""Numerical integration routines for Bayesian models.

Random Seed Strategy: {numerics_seed_strategy}
"""

from __future__ import annotations

import warnings
from collections.abc import Callable

import numpy as np
from scipy.special import logsumexp
from scipy.stats import norm

from clintrials.core.stats import ProbabilityDensitySample


def posterior_expectation_gh(log_likelihood_func, f_func, prior_mean, prior_sd, deg=20):  # type: ignore
    """Evaluates the posterior expectation of f(theta) using Gauss-Hermite quadrature.

    Assuming a Gaussian prior N(prior_mean, prior_sd^2).

    Args:
        log_likelihood_func (Callable): A function taking a 1D array of parameter nodes
            and returning the corresponding log-likelihoods.
        f_func (Callable): A function taking a 1D array of parameter nodes
            and returning the values of the function to be integrated.
            Can return an array of shape (..., num_nodes) for multiple queries.
        prior_mean (float): The mean of the Gaussian prior.
        prior_sd (float): The standard deviation of the Gaussian prior.
        deg (int): The number of quadrature nodes. Defaults to 20.

    Returns:
        float or numpy.ndarray: The computed posterior expectation(s).
    """
    nodes, weights = np.polynomial.hermite.hermgauss(deg)  # type: ignore[no-untyped-call]
    theta_nodes = prior_mean + np.sqrt(2) * prior_sd * nodes
    log_w = np.log(weights)

    ll = log_likelihood_func(theta_nodes)
    log_post = log_w + ll
    log_denom = logsumexp(log_post)
    post_weights = np.exp(log_post - log_denom)

    f_vals = f_func(theta_nodes)
    return np.sum(post_weights * f_vals, axis=-1)


def adaptive_mc_integration(  # type: ignore
    lik_integrand,
    initial_limits,
    rng,
    n=10000,
    max_iter=5,
    mass_threshold=0.999,
    k_sd=3.5,
):
    """Performs adaptive multi-dimensional Monte Carlo integration.

    Args:
        lik_integrand (Callable): Function taking a 2D array of samples
            and returning an array of evaluated likelihoods * priors.
        initial_limits (list[tuple[float, float]]): Initial integration bounds
            for each dimension.
        rng (numpy.random.Generator): Random number generator.
        n (int): Number of Monte Carlo samples per iteration. Defaults to 10000.
        max_iter (int): Maximum iterations for expanding limits. Defaults to 5.
        mass_threshold (float): The target Gaussian coverage threshold
            for convergence. Defaults to 0.999.
        k_sd (float): The multiplier for the standard deviation when
            expanding limits. Defaults to 3.5.

    Returns:
        tuple[list[tuple[float, float]], ProbabilityDensitySample]: A tuple
            containing the refined limits and the ProbabilityDensitySample.
    """
    limits = initial_limits
    num_dims = len(limits)

    for i in range(max_iter):
        samp = np.column_stack(
            [rng.uniform(*limit_pair, size=n) for limit_pair in limits]
        )
        pds = ProbabilityDensitySample(samp, lik_integrand)

        means = [pds.expectation(samp[:, j]) for j in range(num_dims)]  # type: ignore
        variances = [pds.variance(samp[:, j]) for j in range(num_dims)]  # type: ignore
        sds = [np.sqrt(v) if v > 0 else 0 for v in variances]

        needs_refinement = False
        refined_limits = []
        for j in range(num_dims):
            m, s = means[j], sds[j]
            low, high = limits[j]

            if s > 0:
                coverage = norm.cdf(high, loc=m, scale=s) - norm.cdf(
                    low, loc=m, scale=s
                )
            else:
                coverage = 1.0 if low <= m <= high else 0.0

            if coverage < mass_threshold:
                target_low = m - k_sd * s
                target_high = m + k_sd * s
                new_low = min(low, target_low)
                new_high = max(high, target_high)
                refined_limits.append((new_low, new_high))
                needs_refinement = True
            else:
                refined_limits.append((low, high))

        limits = refined_limits
        if not needs_refinement:
            break

        if i == max_iter - 1:
            import logging

            logging.warning(
                "Monte Carlo integration limits did not cover mass threshold after %d iterations.",
                max_iter,
            )

    return limits, pds


def integrate_posterior_1d(  # type: ignore
    logpost: Callable,  # type: ignore
    f: Callable,  # type: ignore
    lo: float,
    hi: float,
    *,
    method: str = "grid",
    n_points: int = 2001,
    adaptive_limits: bool = True,
    edge_frac: float = 0.02,
    tail_mass_tol: float = 1e-3,
    expand_factor: float = 1.0,
    max_expansions: int = 6,
    warn_on_max: bool = True,
    return_diagnostics: bool = False,
):
    """Integrate a 1D posterior density with optional adaptive bounds.

    Args:
        logpost (Callable): Log posterior density function evaluated on a
            numpy array.
        f (Callable): Function of the parameter to integrate with respect to
            the posterior density.
        lo (float): Initial lower bound of integration.
        hi (float): Initial upper bound of integration.
        method (str, optional): Integration method. Only "grid" is
            implemented. A linspace grid of `n_points` is used.
            Defaults to "grid".
        n_points (int, optional): Number of grid points in the integration
            domain. Defaults to 2001.
        adaptive_limits (bool, optional): If `True`, iteratively expand the
            integration limits when tail mass near the boundary exceeds
            `tail_mass_tol`. Defaults to True.
        edge_frac (float, optional): Fraction of the width considered to be
            the edge for the tail mass heuristic. Defaults to 0.02.
        tail_mass_tol (float, optional): Maximum tolerated posterior mass in
            the edges before expansion is triggered. Defaults to 1e-3.
        expand_factor (float, optional): Fractional increase of the current
            width when expanding limits. Defaults to 1.0.
        max_expansions (int, optional): Maximum number of expansions before
            giving up. Defaults to 6.
        warn_on_max (bool, optional): Issue a warning when expansion hits
            `max_expansions`. Defaults to True.
        return_diagnostics (bool, optional): If `True`, return a dict with
            diagnostics in addition to the integral value. Defaults to False.

    Returns:
        float or tuple: The integral value, or a tuple containing the
            integral value and a diagnostics dictionary if `return_diagnostics`
            is `True`.
    """
    expansions = 0
    while True:
        xs = np.linspace(lo, hi, n_points)
        lp = logpost(xs)
        w = np.exp(lp - logsumexp(lp))
        val = np.sum(w * f(xs))

        width = hi - lo
        left = xs <= lo + edge_frac * width
        right = xs >= hi - edge_frac * width
        tail_mass = w[left].sum() + w[right].sum()
        max_at_edge = np.argmax(lp) == 0 or np.argmax(lp) == len(xs) - 1

        if not adaptive_limits or ((tail_mass < tail_mass_tol) and (not max_at_edge)):
            diag = {
                "expansions": expansions,
                "tail_mass": float(tail_mass),
                "max_at_edge": bool(max_at_edge),
                "log_marginal": float(logsumexp(lp) + np.log(xs[1] - xs[0])),
            }
            return (val, diag) if return_diagnostics else val

        if expansions >= max_expansions:
            if warn_on_max:
                warnings.warn(
                    "Posterior mass remains near bounds after max expansions; results may be biased.",
                    RuntimeWarning,
                )
            diag = {
                "expansions": expansions,
                "tail_mass": float(tail_mass),
                "max_at_edge": bool(max_at_edge),
                "hit_cap": True,
                "log_marginal": float(logsumexp(lp) + np.log(xs[1] - xs[0])),
            }
            return (val, diag) if return_diagnostics else val

        lo -= expand_factor * width / 2
        hi += expand_factor * width / 2
        expansions += 1

def integrate_posterior_1d_adaptive(  # type: ignore
    logpost,
    f,
    lo,
    hi,
    *,
    method="grid",
    n_points=2001,
    edge_frac=0.02,
    tail_mass_tol=1e-3,
    expand_factor=1.0,
    max_expansions=6,
    warn_on_max=True,
    return_diagnostics=False,
):
    """Adaptive execution interface for posterior integration."""
    return integrate_posterior_1d(
        logpost, f, lo, hi,
        method=method,
        n_points=n_points,
        adaptive_limits=True,
        edge_frac=edge_frac,
        tail_mass_tol=tail_mass_tol,
        expand_factor=expand_factor,
        max_expansions=max_expansions,
        warn_on_max=warn_on_max,
        return_diagnostics=return_diagnostics,
    )

def integrate_posterior_1d_nonadaptive(  # type: ignore
    logpost,
    f,
    lo,
    hi,
    *,
    method="grid",
    n_points=2001,
    return_diagnostics=False,
):
    """Legacy non-adaptive execution interface for posterior integration."""
    return integrate_posterior_1d(
        logpost, f, lo, hi,
        method=method,
        n_points=n_points,
        adaptive_limits=False,
        return_diagnostics=return_diagnostics,
    )

# Inject module-level docstring
if __doc__:
    from clintrials.core.registry import CORE_REGISTRY
    __doc__ = __doc__.format(**CORE_REGISTRY)
