# SPDX-License-Identifier: MIT

"""Centralized registry for all statistical constants."""

from __future__ import annotations

from typing import Any, Dict

CORE_REGISTRY: Dict[str, Any] = {
    # Integration limits
    "gsd_maxpts": 1000000,
    "gsd_abseps": 1e-5,

    # Quadrature nodes
    "crm_deg": 40,

    # CRM Integration parameters
    "crm_min_beta": -10,
    "crm_max_beta": 10,
    "crm_n_points": 2001,
    "crm_sample_size": 1000000,

    # Search intervals
    "gsd_brentq_first_min": -5,
    "gsd_brentq_first_max": 15,
    "gsd_brentq_second_min": -50,
    "gsd_brentq_second_max": 50,

    # Math constants (beta clipping)
    "math_clip_beta_min": -10,
    "math_clip_beta_max": 10,

    # Random seeds
    "gsd_multivariate_normal_seed": 42,
    "gsd_seed_strategy": "fixed seed (42)",
    "crm_seed_strategy": "global state",
    "math_seed_strategy": "not applicable",
    "validation_seed_strategy": "not applicable",
    "utils_seed_strategy": "not applicable",
    "unified_seed_strategy": "not applicable",
    "simulation_seed_strategy": "not applicable",
    "tte_seed_strategy": "not applicable",
    "schema_seed_strategy": "not applicable",
    "viz_interface_seed_strategy": "not applicable",
    "numerics_seed_strategy": "global state",
    "recruitment_seed_strategy": "not applicable",
    "stats_seed_strategy": "not applicable",
    "rng_seed_strategy": "not applicable",
    "report_seed_strategy": "not applicable",
    "protocol_seed_strategy": "not applicable",
    "provider_seed_strategy": "not applicable",
    "factory_seed_strategy": "not applicable",
    "main_seed_strategy": "not applicable",
    "winratio_view_seed_strategy": "not applicable",
    "crm_view_seed_strategy": "not applicable",
    "efftox_view_seed_strategy": "not applicable",
    "simulate_seed_strategy": "deterministic",
    "data_generation_seed_strategy": "local/seeded",
    "winratio_seed_strategy": "local/seeded",
    "compare_seed_strategy": "not applicable",
    "statistics_seed_strategy": "not applicable",
    "simple_seed_strategy": "not applicable",
    "peps2v1_seed_strategy": "not applicable",
    "peps2v2_seed_strategy": "not applicable",
    "efftox_seed_strategy": "global state",
    "efficacytoxicity_seed_strategy": "not applicable",
    "watu_seed_strategy": "not applicable",
    "wagestait_seed_strategy": "not applicable",

}

import importlib
import logging
import pkgutil
from typing import TYPE_CHECKING, Callable, List, Optional

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    pass

class ProtocolRegistry:
    """A registry for clinical trial protocol designs and their visualization methods."""

    def __init__(self) -> None:
        """Initializes a new ProtocolRegistry instance."""
        self._designs: Dict[str, Dict[str, Any]] = {}
        self._discovered: bool = False

    def _discover(self) -> None:
        if self._discovered:
            return
        self._discovered = True
        try:
            import clintrials.visualization.dashboard.views as views
            if views.__path__:
                for _, name, _ in pkgutil.iter_modules(views.__path__):
                    if name.endswith("_view"):
                        importlib.import_module(f"clintrials.visualization.dashboard.views.{name}")
        except Exception:
            pass

    def register(self, name: str, preview_func: Optional[Callable] = None) -> Callable:  # type: ignore
        """Register a protocol design with an optional preview simulation function.

        Args:
            name (str): The name of the protocol design.
            preview_func (callable, optional): A function to generate a preview simulation.
                Defaults to None.

        Returns:
            callable: A decorator function for registering the render method.
        """
        def decorator(render_func: Callable) -> Callable:  # type: ignore
            if name in self._designs:
                logger.warning(f"Duplicate registration encountered for design name: {name}")
            else:
                self._designs[name] = {}
            self._designs[name]["render"] = render_func
            if preview_func:
                self._designs[name]["preview"] = preview_func
            return render_func
        return decorator

    def register_manual(self, name: str, render_func: Callable, preview_func: Optional[Callable] = None) -> None:  # type: ignore
        """Manually register a protocol design with its render and preview functions."""
        if name in self._designs:
            logger.warning(f"Duplicate manual registration encountered for design name: {name}")
        self._designs[name] = {"render": render_func, "preview": preview_func}

    def get_designs(self) -> List[str]:
        """Get a list of all registered protocol design names."""
        self._discover()
        return list(self._designs.keys())

    def get_render(self, name: str) -> Optional[Callable]:  # type: ignore
        """Get the render function for a registered protocol design."""
        self._discover()
        return self._designs.get(name, {}).get("render")

    def get_preview(self, name: str) -> Optional[Callable]:  # type: ignore
        """Get the preview function for a registered protocol design."""
        self._discover()
        return self._designs.get(name, {}).get("preview")

PROTOCOL_REGISTRY = ProtocolRegistry()

def inject_docs() -> Callable:  # type: ignore
    """Decorator to inject registry constants into docstrings."""
    def decorator(obj: Any) -> Any:
        if obj.__doc__:
            obj.__doc__ = obj.__doc__.format(**CORE_REGISTRY)
        return obj
    return decorator


class RunnerRegistry:
    """Registry to map trial designs (Protocol classes or string names) to simulation runners and result containers."""

    def __init__(self) -> None:
        """Initializes a new RunnerRegistry instance."""
        self._registry: Dict[Any, tuple[Any, Any]] = {}
        self._default_runner: Any = None
        self._default_result_container: Any = None

    def set_defaults(self, runner: Any, result_container: Any) -> None:
        """Set the default runner and result container."""
        self._default_runner = runner
        self._default_result_container = result_container

    def register(self, design: Any, runner: Optional[Any] = None, result_container: Optional[Any] = None) -> Any:
        """Register a runner and optional result container for a specific trial design.

        Can be used as a function call or as a decorator on the runner class.

        Args:
            design: The trial design class (or string name).
            runner: The simulation runner class or callable. Optional if used as decorator.
            result_container: The result container class or callable. Optional.
        """
        if runner is None:
            # Decorator usage: @RUNNER_REGISTRY.register(design, result_container=...)
            def decorator(runner_cls: Any) -> Any:
                self.register(design, runner_cls, result_container)
                return runner_cls
            return decorator

        # Validation
        if design is None:
            raise ValueError(
                "Unable to register: The 'design' parameter cannot be None.\n"
                "Troubleshooting:\n"
                "1. Ensure you pass a valid clinical trial design class (subclassing Protocol) or a string identifier.\n"
                "2. Check that the design class is fully imported and defined before registration."
            )
        if not isinstance(design, (type, str)):
            raise TypeError(
                f"Unable to register: Invalid 'design' parameter type '{type(design).__name__}'.\n"
                "Troubleshooting:\n"
                "1. The design parameter must be a Python class or a string identifier.\n"
                "2. If you are registering a custom runner for a Protocol class, pass the class name or the class object itself (e.g., DummyTrial)."
            )
        if runner is None:
            raise ValueError(
                "Unable to register: The 'runner' parameter cannot be None.\n"
                "Troubleshooting:\n"
                "1. Provide a valid simulation runner class or callable.\n"
                "2. The runner must implement a 'run' method matching the expected simulation execution interface."
            )
        if not callable(runner):
            raise TypeError(
                f"Unable to register: The 'runner' parameter must be callable (a class or function). Got: '{type(runner).__name__}'.\n"
                "Troubleshooting:\n"
                "1. Ensure the runner is a class definition or a factory function, not an instantiated object.\n"
                "2. If it is a custom class, verify it is defined correctly before calling register."
            )
        if result_container is not None and not callable(result_container):
            raise TypeError(
                f"Unable to register: The 'result_container' parameter must be callable. Got: '{type(result_container).__name__}'.\n"
                "Troubleshooting:\n"
                "1. Ensure the result_container is a class or factory function that wraps execution results.\n"
                "2. Pass None or omit the argument if you want to use the default unified SimulationResult container."
            )

        self._registry[design] = (runner, result_container)

    def resolve(self, design: Any) -> tuple[Any, Any]:
        """Resolve the simulation runner and result container for a given trial design (Protocol instance or class)."""
        design_class = design if isinstance(design, type) else type(design)

        # 1. Try resolving by exact class
        if design_class in self._registry:
            runner, result_container = self._registry[design_class]
            if self._default_runner is None or self._default_result_container is None:
                self._load_defaults()
            return runner, result_container or self._default_result_container

        # 2. Try resolving by string representation or name
        if hasattr(design_class, "__name__") and design_class.__name__ in self._registry:
            runner, result_container = self._registry[design_class.__name__]
            if self._default_runner is None or self._default_result_container is None:
                self._load_defaults()
            return runner, result_container or self._default_result_container

        # 3. Try inheritance lookup (MRO search for any registered class)
        if hasattr(design_class, "__mro__"):
            for parent in design_class.__mro__:
                if parent in self._registry:
                    runner, result_container = self._registry[parent]
                    if self._default_runner is None or self._default_result_container is None:
                        self._load_defaults()
                    return runner, result_container or self._default_result_container

        # 4. Fallback to default
        if self._default_runner is None or self._default_result_container is None:
            self._load_defaults()

        return self._default_runner, self._default_result_container

    def _load_defaults(self) -> None:
        if self._default_runner is None:
            from clintrials.core.simulation import UniversalProtocolSimulationRunner
            self._default_runner = UniversalProtocolSimulationRunner
        if self._default_result_container is None:
            from clintrials.core.unified import SimulationResult
            self._default_result_container = SimulationResult


RUNNER_REGISTRY = RunnerRegistry()


