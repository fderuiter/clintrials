"""Unified container structures for simulation results."""

from __future__ import annotations


class SimulationResult:
    """Unified result container for simulation runs."""

    def __init__(self, results, mode="iterative"):  # type: ignore
        """Initialize the SimulationResult with results and execution mode."""
        self.results = results
        self.mode = mode

    def __iter__(self):  # type: ignore
        """Iterate over the underlying results."""
        return iter(self.results)

    def __len__(self):  # type: ignore
        """Return the count of items in the underlying results."""
        return len(self.results)

    def __getitem__(self, key_or_idx):  # type: ignore
        """Retrieve an item by its key or index."""
        return self.results[key_or_idx]

    def get(self, key, default=None):  # type: ignore
        """Get an item by key from the results dictionary."""
        if isinstance(self.results, dict):
            return self.results.get(key, default)
        raise AttributeError("Underlying results are not a dictionary.")

    def keys(self):  # type: ignore
        """Return the keys of the results dictionary."""
        if isinstance(self.results, dict):
            return self.results.keys()
        raise AttributeError("Underlying results are not a dictionary.")

    def values(self):  # type: ignore
        """Return the values of the results dictionary."""
        if isinstance(self.results, dict):
            return self.results.values()
        raise AttributeError("Underlying results are not a dictionary.")

    def items(self):  # type: ignore
        """Return the items of the results dictionary."""
        if isinstance(self.results, dict):
            return self.results.items()
        raise AttributeError("Underlying results are not a dictionary.")

    def to_list(self):  # type: ignore
        """Convert the results to a list."""
        if isinstance(self.results, dict):
            return [self.results]
        return list(self.results)
