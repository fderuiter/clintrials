# SPDX-License-Identifier: MIT

"""Time-to-event trial designs.

Random Seed Strategy: {tte_seed_strategy}
"""

from __future__ import annotations

__author__ = "Kristian Brock"
__contact__ = "kristian.brock@gmail.com"


from collections import OrderedDict
from typing import Any

import numpy as np
from scipy.stats import expon, invgamma

from clintrials.core.protocol import Protocol
from clintrials.core.simulation import UniversalProtocolSimulationRunner
from clintrials.utils import atomic_to_json, iterable_to_json


class BayesianTimeToEvent(Protocol):
    """A Bayesian design for time-to-event endpoints.

    This class implements a simple adaptive Bayesian design for time-to-event
    endpoints. It assumes exponentially distributed event times and an
    inverse-gamma prior on the median survival time.

    See Thall, P.F., Wooten, L.H., & Tannir, N.M. (2005) - "Monitoring Event
    Times in Early Phase Clinical Trials: Some Practical Issues" for details.
    """

    def __init__(self, alpha_prior: float, beta_prior: float) -> None:
        """Initializes a BayesianTimeToEvent object.

        Args:
            alpha_prior (float): The alpha parameter of the inverse-gamma prior
                on the median time-to-event.
            beta_prior (float): The beta parameter of the inverse-gamma prior on
                the median time-to-event.
        """
        super().__init__()
        self.alpha_prior = alpha_prior
        self.beta_prior = beta_prior
        self._times_to_event: list[float] = []
        self._recruitment_times: list[float] = []

        # Additional simulation / trial configuration parameters
        self.n_patients: int = 0
        self.true_median: float = 0.0
        self.lower_cutoff: float = 0.0
        self.upper_cutoff: float = 0.0
        self.interim_certainty: float = 0.0
        self.final_certainty: float = 0.0
        self.interim_analysis_after_patients: list[int] = []
        self.interim_analysis_time_delta: float = 0.0
        self.final_analysis_time_delta: float = 0.0

        # State tracking for simulation
        self.interim_analyses_results: list[OrderedDict[Any, Any]] = []
        self._checked_interims: set[int] = set()
        self._stopped_early: bool = False
        self._final_analysis: OrderedDict[Any, Any] | None = None

    def event_times(self) -> list[float]:
        """Gets the list of event times.

        Returns:
            list[float]: A list of event times in the order they were provided.
        """
        return self._times_to_event

    def recruitment_times(self) -> list[float]:
        """Gets the list of recruitment times.

        Returns:
            list[float]: A list of recruitment times in the order they were
                provided.
        """
        return self._recruitment_times

    def reset(self) -> None:
        """Resets the trial to its initial state."""
        self._times_to_event = []
        self._recruitment_times = []
        self.interim_analyses_results = []
        self._checked_interims = set()
        self._stopped_early = False
        self._final_analysis = None

    def update(self, cases: list[tuple[float, float]], *args: Any, **kwargs: Any) -> None:
        """Updates the trial with new patient cases and runs any pending interim analyses."""
        for event_time, recruitment_time in cases:
            self._times_to_event.append(event_time)
            self._recruitment_times.append(recruitment_time)

        # Run any pending interim analysis checks
        recruitment_times = np.array(self._recruitment_times)
        for x in self.interim_analysis_after_patients:
            if x <= len(recruitment_times) and x < self.n_patients:
                if x not in self._checked_interims:
                    self._checked_interims.add(x)
                    time = recruitment_times[x - 1] + self.interim_analysis_time_delta
                    interim_outcome = self.test(
                        time, self.lower_cutoff, self.interim_certainty, less_than=True
                    )
                    self.interim_analyses_results.append(interim_outcome)
                    if interim_outcome["Stop"]:
                        self._stopped_early = True
                        self._final_analysis = interim_outcome
                        break

    def has_more(self) -> bool:
        """Checks if the trial is ongoing (has not stopped early)."""
        return not self._stopped_early

    def max_size(self) -> int:
        """Gets the maximum number of patients for the trial."""
        return self.n_patients

    def report(self) -> OrderedDict[Any, Any]:
        """Returns a standardized, ordered, JSON-serializable report."""
        trial_report: OrderedDict[str, Any] = OrderedDict()
        trial_report["MaxPatients"] = self.n_patients
        trial_report["TrueMedianEventTime"] = self.true_median
        trial_report["PriorAlpha"] = self.alpha_prior
        trial_report["PriorBeta"] = self.beta_prior
        trial_report["LowerCutoff"] = self.lower_cutoff
        trial_report["UpperCutoff"] = self.upper_cutoff
        trial_report["InterimCertainty"] = self.interim_certainty
        trial_report["FinalCertainty"] = self.final_certainty
        trial_report["InterimAnalysisAfterPatients"] = self.interim_analysis_after_patients
        trial_report["InterimAnalysisTimeDelta"] = self.interim_analysis_time_delta
        trial_report["FinalAnalysisTimeDelta"] = self.final_analysis_time_delta

        trial_report["RecruitmentTimes"] = iterable_to_json(self._recruitment_times)  # type: ignore
        trial_report["EventTimes"] = iterable_to_json(self._times_to_event)  # type: ignore
        trial_report["InterimAnalyses"] = self.interim_analyses_results

        if self._stopped_early and self._final_analysis is not None:
            trial_report["Decision"] = "StopAtInterim"
            trial_report["FinalAnalysis"] = self._final_analysis
            trial_report["FinalPatients"] = self._final_analysis["Patients"]
            trial_report["FinalEvents"] = self._final_analysis["Events"]
            trial_report["FinalTotalEventTime"] = self._final_analysis["TotalEventTime"]
        else:
            final_analysis_time = max(self._recruitment_times) + self.final_analysis_time_delta
            final_outcome = self.test(
                final_analysis_time, self.upper_cutoff, self.final_certainty, less_than=False
            )
            trial_report["FinalAnalysis"] = final_outcome
            stop_trial = final_outcome["Stop"]
            decision = "StopAtFinal" if stop_trial else "GoAtFinal"
            trial_report["Decision"] = decision
            trial_report["FinalPatients"] = final_outcome["Patients"]
            trial_report["FinalEvents"] = final_outcome["Events"]
            trial_report["FinalTotalEventTime"] = final_outcome["TotalEventTime"]

        return trial_report

    def test(
        self,
        time: float,
        cutoff: float,
        probability: float,
        less_than: bool = True,
    ) -> OrderedDict[Any, Any]:
        """Tests the posterior belief about the median time-to-event.

        This method tests whether the median time-to-event is less than or
        greater than a certain cutoff value, based on the posterior
        distribution.

        Args:
            time (float): The time at which to perform the test.
            cutoff (float): The critical value to test the median time against.
            probability (float): The required posterior certainty to declare
                significance.
            less_than (bool, optional): If `True`, tests if the parameter is
                less than the cutoff. If `False`, tests if it is greater.
                Defaults to `True`.

        Returns:
            collections.OrderedDict: A dictionary containing the test results.
        """
        event_time = np.array(self._times_to_event)
        recruit_time = np.array(self._recruitment_times)

        # Filter to just patients who are registered by time
        registered_patients = recruit_time <= time
        has_failed = (
            time - recruit_time[registered_patients] > event_time[registered_patients]
        )
        survival_time = np.array(
            [
                min(x, y)
                for (x, y) in zip(
                    time - recruit_time[registered_patients],
                    event_time[registered_patients],
                )
            ]
        )
        # Update posterior beliefs for mu_E
        alpha_post = self.alpha_prior + sum(has_failed)
        beta_post = self.beta_prior + np.log(2) * sum(survival_time)
        mu_post = beta_post / (alpha_post - 1)

        # Run test:
        test_probability = (
            invgamma.cdf(cutoff, a=alpha_post, scale=beta_post)
            if less_than
            else 1 - invgamma.cdf(cutoff, a=alpha_post, scale=beta_post)
        )
        stop_trial = (
            test_probability > probability
            if less_than
            else test_probability < probability
        )

        test_report: OrderedDict[str, Any] = OrderedDict()
        test_report["Time"] = time
        test_report["Patients"] = sum(registered_patients)
        test_report["Events"] = sum(has_failed)
        test_report["TotalEventTime"] = sum(survival_time)
        test_report["AlphaPosterior"] = alpha_post
        test_report["BetaPosterior"] = beta_post
        test_report["MeanEventTimePosterior"] = mu_post
        test_report["MedianEventTimePosterior"] = mu_post * np.log(2)
        test_report["Cutoff"] = cutoff
        test_report["Certainty"] = probability
        test_report["Probability"] = test_probability
        test_report["LessThan"] = atomic_to_json(less_than)  # type: ignore
        test_report["Stop"] = atomic_to_json(stop_trial)  # type: ignore
        return test_report


class TimeToEventOutcomeGenerator:
    """Standard dynamic outcome generator for time-to-event simulation."""

    def __init__(self, true_median: float) -> None:
        """Initializes a TimeToEventOutcomeGenerator object.

        Args:
            true_median (float): The true median time-to-event.
        """
        self.true_median = true_median

    def __call__(self, design: Any, current_size: int, cohort_size: int, **kwargs: Any) -> Any:
        """Generates patient outcomes conforming to the standard OutcomeGenerator interface."""
        true_mean = self.true_median / np.log(2)
        arrival_times = kwargs.get("arrival_times", [])

        # Determine seed/rng strategy to maintain reproducibility
        rng = getattr(design, "_rng", None)

        event_times = expon(scale=true_mean).rvs(size=cohort_size, random_state=rng)
        return [(x, y) for x, y in zip(event_times, arrival_times)]


def matrix_cohort_analysis(
    n_simulations: int,
    n_patients: int,
    true_median: float,
    alpha_prior: float,
    beta_prior: float,
    lower_cutoff: float,
    upper_cutoff: float,
    interim_certainty: float,
    final_certainty: float,
    interim_analysis_after_patients: list[int],
    interim_analysis_time_delta: float,
    final_analysis_time_delta: float,
    recruitment_stream: Any,
) -> Any:
    """Simulates time-to-event outcomes for a cohort.

    This function simulates a time-to-event trial based on the design of the
    National Lung Matrix trial.

    Args:
        n_simulations (int): The number of simulations to run.
        n_patients (int): The number of patients in the cohort.
        true_median (float): The true median time-to-event.
        alpha_prior (float): The alpha parameter of the inverse-gamma prior.
        beta_prior (float): The beta parameter of the inverse-gamma prior.
        lower_cutoff (float): The lower cutoff for the median time-to-event
            at interim analyses.
        upper_cutoff (float): The upper cutoff for the median time-to-event
            at the final analysis.
        interim_certainty (float): The required posterior certainty for
            stopping at interim analyses.
        final_certainty (float): The required posterior certainty for the
            final analysis.
        interim_analysis_after_patients (list[int]): A list of patient counts
            after which to perform interim analyses.
        interim_analysis_time_delta (float): The time delta to add to the
            recruitment time for interim analyses.
        final_analysis_time_delta (float): The time delta to add to the
            last recruitment time for the final analysis.
        recruitment_stream (clintrials.core.recruitment.RecruitmentStream):
            The recruitment stream to use for simulating patient arrival.

    Returns:
        list or dict: A list of simulation reports, or a single report if
            `n_simulations` is 1.
    """
    design = BayesianTimeToEvent(alpha_prior, beta_prior)
    design.n_patients = n_patients
    design.true_median = true_median
    design.lower_cutoff = lower_cutoff
    design.upper_cutoff = upper_cutoff
    design.interim_certainty = interim_certainty
    design.final_certainty = final_certainty
    design.interim_analysis_after_patients = interim_analysis_after_patients
    design.interim_analysis_time_delta = interim_analysis_time_delta
    design.final_analysis_time_delta = final_analysis_time_delta

    runner = UniversalProtocolSimulationRunner(
        design=design,
        outcome_generator=TimeToEventOutcomeGenerator(true_median),
        recruitment_stream=recruitment_stream,
    )

    results = runner.run(mode="iterative", n_sims=n_simulations, cohort_size=n_patients)

    if n_simulations == 1:
        return results[0]
    else:
        return results


# Inject module-level docstring
if __doc__:
    from clintrials.core.registry import CORE_REGISTRY
    __doc__ = __doc__.format(**CORE_REGISTRY)
