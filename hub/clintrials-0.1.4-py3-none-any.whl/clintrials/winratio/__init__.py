"""Win-ratio simulation utilities."""

from __future__ import annotations

from .compare import compare_subjects
from .data_generation import generate_data
from .simulate import simulate_comparisons
from .statistics import (
    calculate_confidence_intervals,
    calculate_p_value,
    calculate_win_ratio,
)

__all__ = [
    "compare_subjects",
    "generate_data",
    "simulate_comparisons",
    "calculate_confidence_intervals",
    "calculate_p_value",
    "calculate_win_ratio",
]
