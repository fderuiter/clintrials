"""Statistical helpers for win-ratio simulations.

Random Seed Strategy: {statistics_seed_strategy}
"""

from __future__ import annotations

import numpy as np

from clintrials.core.stats import log_scale_p_value, log_scale_wald_interval


def calculate_confidence_intervals(wr: float, wins: int, losses: int):  # type: ignore
    """Calculate the 95% confidence intervals for the win ratio.

    Args:
        wr (float): The win ratio.
        wins (int): The number of wins.
        losses (int): The number of losses.

    Returns:
        tuple[float, float]: A tuple containing the lower and upper bounds of
            the confidence interval.
    """
    from clintrials.core.errors import ErrorTemplates
    if wins < 0:
        raise ValueError(ErrorTemplates.GE.format(name="wins", bound=0))
    if losses < 0:
        raise ValueError(ErrorTemplates.GE.format(name="losses", bound=0))
    if wins == 0:
        raise ValueError(ErrorTemplates.GT.format(name="wins", bound=0))
    if losses == 0:
        raise ValueError(ErrorTemplates.GT.format(name="losses", bound=0))
    if wr <= 0:
        raise ValueError(ErrorTemplates.GT.format(name="wr", bound=0))

    variance = 1 / wins + 1 / losses
    if variance < 0:
        raise ValueError("Variance cannot be negative.")
    standard_error = np.sqrt(variance)
    return log_scale_wald_interval(wr, standard_error)


def calculate_p_value(wr: float, wins: int, losses: int) -> float:
    """Calculate the p-value for the observed win ratio.

    Args:
        wr (float): The win ratio.
        wins (int): The number of wins.
        losses (int): The number of losses.

    Returns:
        float: The p-value.
    """
    from clintrials.core.errors import ErrorTemplates
    if wins < 0:
        raise ValueError(ErrorTemplates.GE.format(name="wins", bound=0))
    if losses < 0:
        raise ValueError(ErrorTemplates.GE.format(name="losses", bound=0))
    if wins == 0:
        raise ValueError(ErrorTemplates.GT.format(name="wins", bound=0))
    if losses == 0:
        raise ValueError(ErrorTemplates.GT.format(name="losses", bound=0))
    if wr <= 0:
        raise ValueError(ErrorTemplates.GT.format(name="wr", bound=0))

    variance = 1 / wins + 1 / losses
    if variance < 0:
        raise ValueError("Variance cannot be negative.")
    standard_error = np.sqrt(variance)
    return log_scale_p_value(wr, standard_error)


def calculate_win_ratio(wins: int, losses: int) -> float:
    """Calculate the win ratio.

    Args:
        wins (int): The number of wins.
        losses (int): The number of losses.

    Returns:
        float: The win ratio, or infinity if there are no losses.
    """
    from clintrials.core.errors import ErrorTemplates
    if wins < 0:
        raise ValueError(ErrorTemplates.GE.format(name="wins", bound=0))
    if losses < 0:
        raise ValueError(ErrorTemplates.GE.format(name="losses", bound=0))
    if losses == 0:
        raise ValueError(ErrorTemplates.GT.format(name="losses", bound=0))
    return wins / losses


# Inject module-level docstring
if __doc__:
    from clintrials.core.registry import CORE_REGISTRY
    __doc__ = __doc__.format(**CORE_REGISTRY)
